const express = require('express');
const router = express.Router();
const Vehicle = require('../models/Vehicle');
const upload = require('../config/multerConfig');

// List all vehicles (public view)
router.get('/', async (req, res) => {
  const vehicles = await Vehicle.find();
  res.render('vehicles/index', { vehicles });
});

// Admin: Show new vehicle form
router.get('/admin/new', (req, res) => {
  res.render('vehicles/new');
});

// Admin: Create vehicle
router.post('/admin', upload.single('image'), async (req, res) => {
  const { name, brand, price, type } = req.body;
  const image = req.file ? '/uploads/' + req.file.filename : '';
  await Vehicle.create({ name, brand, price, type, image });
  res.redirect('/vehicles');
});

// Admin: Show edit form
router.get('/admin/:id/edit', async (req, res) => {
  const vehicle = await Vehicle.findById(req.params.id);
  res.render('vehicles/edit', { vehicle });
});

// Admin: Update vehicle
router.post('/admin/:id', upload.single('image'), async (req, res) => {
  const { name, brand, price, type } = req.body;
  const updateData = { name, brand, price, type };
  if (req.file) updateData.image = '/uploads/' + req.file.filename;
  await Vehicle.findByIdAndUpdate(req.params.id, updateData);
  res.redirect('/vehicles');
});

// Admin: Delete vehicle
router.post('/admin/:id/delete', async (req, res) => {
  await Vehicle.findByIdAndDelete(req.params.id);
  res.redirect('/vehicles');
});

module.exports = router;
