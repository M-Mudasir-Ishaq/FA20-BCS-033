document.getElementById("checkoutForm")?.addEventListener("submit", function (e) {
  e.preventDefault();
  let isValid = true;
  const errorFields = document.querySelectorAll(".error");
  errorFields.forEach((el) => el.textContent = "");
  const inputs = document.querySelectorAll(".form-control");
  inputs.forEach((input) => input.classList.remove("is-invalid"));
  // Validate fields similarly as described before...
});