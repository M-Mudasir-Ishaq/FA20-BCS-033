const express = require('express');
const app = express();
const session = require('express-session');
const mongoose = require('mongoose');
const MongoStore = require('connect-mongo');
const path = require('path');

const indexRoutes = require('./routes/index');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/order');

// Connect MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/shopease', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB Connected'));

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

// Session config
app.use(session({
  secret: 'shopease_secret',
  resave: false,
  saveUninitialized: false,
  store: MongoStore.create({ mongoUrl: 'mongodb://127.0.0.1:27017/shopease' }),
}));

// Routes
app.use('/', indexRoutes);
app.use('/cart', cartRoutes);
app.use('/order', orderRoutes);

// Error page
app.use((req, res) => {
  res.status(404).render('error');
});

// Server
app.listen(3000, () => console.log('Server running at http://localhost:3000'));
