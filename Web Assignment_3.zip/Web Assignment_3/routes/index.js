const express = require('express');
const router = express.Router();
const Product = require('../models/product');

// Show products
router.get('/', async (req, res) => {
  const products = await Product.find();
  res.render('landing', { products, cart: req.session.cart });
});

// Add to Cart
router.post('/add-to-cart/:id', async (req, res) => {
  const product = await Product.findById(req.params.id);
  if (!req.session.cart) req.session.cart = [];

  const existing = req.session.cart.find(item => item.productId == product._id);
  if (existing) {
    existing.quantity += 1;
  } else {
    req.session.cart.push({
      productId: product._id,
      title: product.title,
      price: product.price,
      quantity: 1
    });
  }
  res.redirect('/');
});

module.exports = router;
