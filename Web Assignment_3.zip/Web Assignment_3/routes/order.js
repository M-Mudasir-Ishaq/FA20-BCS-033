const express = require('express');
const router = express.Router();
const Order = require('../models/order');

// Checkout Page
router.get('/checkout', (req, res) => {
  const cart = req.session.cart || [];
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  res.render('checkout', { cart, total });
});

// Place Order
router.post('/checkout', async (req, res) => {
  const cart = req.session.cart || [];
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const newOrder = new Order({
    name: req.body.name,
    phone: req.body.phone,
    address: req.body.address,
    items: cart,
    total: total
  });

  await newOrder.save();
  req.session.cart = [];
  res.render('order-success');
});

module.exports = router;
