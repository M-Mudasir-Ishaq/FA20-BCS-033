const express = require('express');
const router = express.Router();

// Show Cart
router.get('/', (req, res) => {
  const cart = req.session.cart || [];
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  res.render('cart', { cart, total });
});

// Remove Item
router.post('/remove/:id', (req, res) => {
  req.session.cart = req.session.cart.filter(item => item.productId != req.params.id);
  res.redirect('/cart');
});

module.exports = router;
