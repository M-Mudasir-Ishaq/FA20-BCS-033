document.querySelector("form").addEventListener("submit", function(e) {
  const name = document.querySelector("[name='name']");
  const phone = document.querySelector("[name='phone']");
  const address = document.querySelector("[name='address']");
  let isValid = true;

  if (name.value.trim() === "") {
    alert("Please enter your name");
    isValid = false;
  }
  if (phone.value.trim().length < 10) {
    alert("Phone number must be at least 10 digits");
    isValid = false;
  }
  if (address.value.trim() === "") {
    alert("Please enter your address");
    isValid = false;
  }

  if (!isValid) e.preventDefault();
});
