const express = require('express');
const router = express.Router();

router.get('/', (req, res) => res.render('landing'));
router.get('/bootstrap', (req, res) => res.render('bootstrap'));
router.get('/checkout', (req, res) => res.render('checkout'));
router.get('/taskloader', (req, res) => res.render('task_loader'));

module.exports = router;